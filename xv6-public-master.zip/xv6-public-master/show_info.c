#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char const *argv[])
{
	show_all_info();
	exit();
}
